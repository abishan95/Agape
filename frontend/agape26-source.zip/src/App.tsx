import { useEffect, useState } from 'react';
import { Icon, IconName } from './components/Icons';
import { AdminPage } from './pages/AdminPage';
import { GamesPage } from './pages/GamesPage';
import { HomePage } from './pages/HomePage';
import { InstallPromptEvent, InstallPromptPage } from './pages/InstallPromptPage';
import { LoginPage } from './pages/LoginPage';
import { ProfilePage } from './pages/ProfilePage';
import { SchedulePage } from './pages/SchedulePage';
import { SongsPage } from './pages/SongsPage';
import { Attendee, findAttendeeByPhone, getAttendees } from './data/mockStore';

type Tab = 'home' | 'schedule' | 'songs' | 'games' | 'profile' | 'admin';
type PublicTab = Exclude<Tab, 'admin'>;
const ATTENDEE_KEY = 'agape:demo-attendee';
const INSTALL_KEY = 'agape:browser-bypass';
const ANNOUNCEMENT_KEY = 'agape:demo-announcement';
const AVATAR_KEY = 'agape:demo-avatar';

const navItems: { id: PublicTab; label: string; icon: IconName }[] = [
  { id: 'home', label: 'Home', icon: 'home' },
  { id: 'schedule', label: 'Plan', icon: 'calendar' },
  { id: 'songs', label: 'Songs', icon: 'music' },
  { id: 'games', label: 'Games', icon: 'game' },
  { id: 'profile', label: 'My Stay', icon: 'user' },
];

function readSavedAttendee(): Attendee | null {
  try {
    const phone = localStorage.getItem(ATTENDEE_KEY);
    return phone ? findAttendeeByPhone(phone) ?? null : null;
  } catch {
    return null;
  }
}

function App() {
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [showInstallGate, setShowInstallGate] = useState(() => {
    try {
      return !localStorage.getItem(INSTALL_KEY) && !window.matchMedia('(display-mode: standalone)').matches;
    } catch {
      return !window.matchMedia('(display-mode: standalone)').matches;
    }
  });
  const [attendee, setAttendee] = useState<Attendee | null>(readSavedAttendee);
  const [tab, setTab] = useState<Tab>('home');
  const [loginError, setLoginError] = useState('');
  const [announcement, setAnnouncement] = useState(() => {
    try { return localStorage.getItem(ANNOUNCEMENT_KEY) || ''; } catch { return ''; }
  });
  const [avatarId, setAvatarId] = useState(() => {
    try { return localStorage.getItem(AVATAR_KEY) || 'sprout'; } catch { return 'sprout'; }
  });

  useEffect(() => {
    const handleInstall = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const handleInstalled = () => {
      setInstallPrompt(null);
      continueInBrowser();
    };
    window.addEventListener('beforeinstallprompt', handleInstall);
    window.addEventListener('appinstalled', handleInstalled);
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(() => undefined);
    }
    return () => {
      window.removeEventListener('beforeinstallprompt', handleInstall);
      window.removeEventListener('appinstalled', handleInstalled);
    };
  }, []);

  function continueInBrowser() {
    try { localStorage.setItem(INSTALL_KEY, '1'); } catch { /* session can continue without storage */ }
    setShowInstallGate(false);
  }

  function signIn(phone: string) {
    const matched = findAttendeeByPhone(phone);
    if (!matched) {
      setLoginError('That number is not in the preview roster. Try a sample account below.');
      return;
    }
    setLoginError('');
    setAttendee(matched);
    setTab('home');
    try { localStorage.setItem(ATTENDEE_KEY, matched.Phone); } catch { /* preview-only session */ }
  }

  function logout() {
    setAttendee(null);
    setTab('home');
    try { localStorage.removeItem(ATTENDEE_KEY); } catch { /* ignore */ }
  }

  function saveAnnouncement(value: string) {
    setAnnouncement(value);
    try {
      if (value) localStorage.setItem(ANNOUNCEMENT_KEY, value);
      else localStorage.removeItem(ANNOUNCEMENT_KEY);
    } catch { /* preview-only announcement state */ }
  }

  function saveAvatar(value: string) {
    setAvatarId(value);
    try { localStorage.setItem(AVATAR_KEY, value); } catch { /* preview-only preference */ }
  }

  function openAdmin() {
    if (attendee?.IsSuperuser) setTab('admin');
  }

  if (showInstallGate) {
    return <InstallPromptPage installPrompt={installPrompt} onInstallPromptUsed={continueInBrowser} onContinue={continueInBrowser} />;
  }
  if (!attendee) {
    return <LoginPage error={loginError} onLogin={signIn} onUseDemo={signInDemo} attendees={getAttendees().filter((record) => !record.IsSuperuser)} />;
  }

  function signInDemo(record: Attendee) {
    signIn(record.Phone);
  }

  const page = (() => {
    switch (tab) {
      case 'home': return <HomePage attendee={attendee} announcement={announcement} onNavigate={setTab} />;
      case 'schedule': return <SchedulePage />;
      case 'songs': return <SongsPage />;
      case 'games': return <GamesPage attendee={attendee} />;
      case 'profile': return <ProfilePage attendee={attendee} avatarId={avatarId} onAvatarChange={saveAvatar} onLogout={logout} onOpenAdmin={openAdmin} />;
      case 'admin': return attendee.IsSuperuser
        ? <AdminPage attendees={getAttendees()} announcement={announcement} onAnnouncementChange={saveAnnouncement} onBack={() => setTab('profile')} />
        : <ProfilePage attendee={attendee} avatarId={avatarId} onAvatarChange={saveAvatar} onLogout={logout} onOpenAdmin={openAdmin} />;
    }
  })();

  return (
    <div className="app-shell">
      <div className="ambient-glow" aria-hidden="true" />
      <header className="app-header">
        <button className="wordmark" type="button" onClick={() => setTab('home')} aria-label="AGAPE Home">
          <img className="brand-logo" src="./agape-logo.png" alt="" />
          <span className="wordmark-text">AGAPE <small>RETREAT <i>2026</i></small></span>
        </button>
        <button className={`id-badge${tab === 'profile' ? ' selected' : ''}`} type="button" aria-label="Open My Stay profile" onClick={() => setTab('profile')}>
          <span className="id-badge-shadow" /><span className="id-emoji">🪪</span>
        </button>
      </header>
      <main className="page-scroll" key={tab}>
        <div className="page-transition">{page}</div>
      </main>
      <nav className="bottom-dock" aria-label="Main navigation">
        {navItems.map((item) => (
          <button className={`nav-item${tab === item.id ? ' active' : ''}`} type="button" key={item.id} onClick={() => setTab(item.id)} aria-current={tab === item.id ? 'page' : undefined}>
            <span className="nav-icon"><Icon name={item.icon} size={19} /></span><span>{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="demo-ribbon">PREVIEW BUILD · SAMPLE DATA</div>
    </div>
  );
}

export default App;
