export interface Attendee {
  Phone: string;
  Name: string;
  Bus: string;
  BusSeat: string;
  Room: string;
  Dorm: string;
  Team: string;
  IsSuperuser: boolean;
}

/**
 * Synthetic preview-only records. The Master Google Spreadsheet is not connected;
 * replace this fixture with a protected server-side roster before collecting attendee PII.
 */
export const mockStore: Attendee[] = [
  {
    Phone: '0000000001',
    Name: 'Retreat Guest',
    Bus: 'Yelagiri · 01',
    BusSeat: '12A',
    Room: 'Pine · 204',
    Dorm: 'Pine Wing · Room 204',
    Team: 'Cedar',
    IsSuperuser: false,
  },
  {
    Phone: '0000000002',
    Name: 'Demo Coordinator',
    Bus: 'Yelagiri · 01',
    BusSeat: '01A',
    Room: 'Cedar · 101',
    Dorm: 'Cedar Wing · Room 101',
    Team: 'Cedar',
    IsSuperuser: true,
  },
  {
    Phone: '0000000003',
    Name: 'Team Demo',
    Bus: 'Yelagiri · 02',
    BusSeat: '08C',
    Room: 'Maple · 108',
    Dorm: 'Maple Wing · Room 108',
    Team: 'Ember',
    IsSuperuser: false,
  },
];

export function normalizePhone(value: string): string {
  const digits = value.replace(/\D/g, '');
  return digits.length > 10 ? digits.slice(-10) : digits;
}

export function findAttendeeByPhone(value: string): Attendee | undefined {
  const phone = normalizePhone(value);
  return mockStore.find((attendee) => attendee.Phone === phone);
}

export function getAttendees(): Attendee[] {
  return mockStore;
}
