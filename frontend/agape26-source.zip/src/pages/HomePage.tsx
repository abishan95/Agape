import { Icon } from '../components/Icons';
import { Attendee } from '../data/mockStore';

type Navigate = (tab: 'home' | 'schedule' | 'songs' | 'games' | 'profile') => void;

interface HomePageProps {
  attendee: Attendee;
  announcement: string;
  onNavigate: Navigate;
}

const AVATAR_URL = '/manus-storage/async-images/efLSesvx0ePGhYZSTO7Mo0/image-1.webp';

export function HomePage({ attendee, announcement, onNavigate }: HomePageProps) {
  const firstName = attendee.Name.split(' ')[0];

  return (
    <section className="home-page">
      <div className="home-intro">
        <div>
          <p className="eyebrow">CICC RETREAT · YELAGIRI</p>
          <h1>Hello,<br /><em>{firstName}.</em></h1>
          <p className="home-subtitle">Your retreat, all in one place.</p>
        </div>
        <span className="home-avatar-bubble" aria-hidden="true">{firstName.slice(0, 1).toUpperCase()}</span>
      </div>

      <article className="announcement-panel" aria-live="polite">
        <div className="announcement-panel-top">
          <span className="announcement-icon"><Icon name="bell" size={20} /></span>
          <span className="announcement-panel-label"><small>RETREAT TEAM</small><b>Announcements</b></span>
          <span className="announcement-badge">{announcement ? 'LATEST' : 'UPDATES'}</span>
        </div>
        <p>{announcement || 'Important retreat updates will appear here.'}</p>
        <span className="announcement-hint">{announcement ? 'Latest update' : 'No announcements yet'}</span>
      </article>

      <article className="pass-card">
        <div className="pass-topline"><img className="pass-brand-logo" src="./agape-logo.png" alt="" /><span>AGAPE <small>RETREAT PASS</small></span><span className="pass-year">2026</span></div>
        <div className="pass-content">
          <div className="pass-copy">
            <span className="pass-overline">CICC · YELAGIRI</span>
            <h2>Gather<br />in grace.</h2>
            <p className="pass-date">Dec 27 — 30 <i>·</i> Yelagiri</p>
          </div>
          <img className="pass-avatar" src={AVATAR_URL} alt="Pastel clay hill station with layered double-exposure hills and cottages" />
        </div>
        <div className="pass-footer"><span><i className="status-led" /> YOUR PASS IS READY</span><span className="pass-code">AG—26</span></div>
      </article>

      <div className="assignment-shelf" aria-label="Your retreat assignments">
        <div className="assignment"><span className="assignment-icon"><Icon name="bus" size={17} /></span><small>BUS</small><b>{attendee.Bus}</b><span className="assignment-sub">Seat {attendee.BusSeat}</span></div>
        <div className="shelf-divider" />
        <div className="assignment"><span className="assignment-icon"><Icon name="bed" size={17} /></span><small>ROOM</small><b>{attendee.Room}</b><span className="assignment-sub">Your dorm</span></div>
        <div className="shelf-divider" />
        <div className="assignment"><span className="assignment-icon team-chip">{attendee.Team.slice(0, 1)}</span><small>TEAM</small><b>{attendee.Team}</b><span className="assignment-sub">Find your people</span></div>
      </div>

      <div className="section-heading"><div><p className="eyebrow">YOUR RETREAT, AT A GLANCE</p><h2>Make it yours.</h2></div><span className="section-index">01 / 04</span></div>
      <div className="feature-grid">
        <button className="feature-card feature-schedule" type="button" onClick={() => onNavigate('schedule')}><span className="feature-number">01</span><span className="feature-icon"><Icon name="calendar" size={21} /></span><b>The plan</b><small>Four days together</small><Icon className="feature-arrow" name="arrow" size={15} /></button>
        <button className="feature-card feature-songs" type="button" onClick={() => onNavigate('songs')}><span className="feature-number">02</span><span className="feature-icon"><Icon name="music" size={21} /></span><b>Songbook</b><small>Sing as one</small><Icon className="feature-arrow" name="arrow" size={15} /></button>
        <button className="feature-card feature-games" type="button" onClick={() => onNavigate('games')}><span className="feature-number">03</span><span className="feature-icon"><Icon name="game" size={21} /></span><b>Team play</b><small>Take on a challenge</small><Icon className="feature-arrow" name="arrow" size={15} /></button>
        <button className="feature-card feature-stay" type="button" onClick={() => onNavigate('profile')}><span className="feature-number">04</span><span className="feature-icon"><Icon name="user" size={21} /></span><b>My Stay</b><small>Your pass & details</small><Icon className="feature-arrow" name="arrow" size={15} /></button>
      </div>
      <div className="home-footer"><span className="footer-ornament">✳</span><p>Carry a little grace<br /><em>into every day.</em></p><span className="footer-ornament">✳</span></div>
    </section>
  );
}
