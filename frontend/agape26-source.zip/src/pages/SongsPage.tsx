import { useMemo, useState } from 'react';
import { Icon } from '../components/Icons';

const songs = [
  { title: 'Amazing Grace', subtitle: 'Traditional · Public domain', key: 'A', lyrics: ['Amazing grace! how sweet the sound, that saved a wretch like me! I once was lost, but now am found; was blind, but now I see.', "’Twas grace that taught my heart to fear, and grace my fears relieved; how precious did that grace appear the hour I first believed."] },
  { title: 'Be Thou My Vision', subtitle: 'Traditional · Public domain', key: 'B', lyrics: ['Be Thou my Vision, O Lord of my heart; naught be all else to me, save that Thou art; Thou my best thought, by day or by night, waking or sleeping, Thy presence my light.'] },
  { title: 'Holy, Holy, Holy', subtitle: 'Reginald Heber · Public domain', key: 'H', lyrics: ['Holy, holy, holy! Lord God Almighty! Early in the morning our song shall rise to Thee; holy, holy, holy, merciful and mighty, God in three Persons, blessed Trinity!'] },
];

export function SongsPage() {
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState<string | null>(songs[0].title);
  const filtered = useMemo(() => songs.filter((song) => `${song.title} ${song.subtitle}`.toLowerCase().includes(query.toLowerCase())), [query]);

  return (
    <section className="content-page songs-page">
      <div className="page-heading"><p className="eyebrow">LYRICS · MELODY · TOGETHER</p><h1>Raise your<br /><em>voice.</em></h1><p className="page-lede">A little collection for the moments we sing together.</p></div>
      <div className="songbook-cover"><div className="songbook-stamp">✳</div><div><small>AGAPE · SONGBOOK</small><b>One song<br />at a time.</b></div><span className="songbook-spine" /></div>
      <div className="song-search"><Icon name="search" size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Find a hymn" aria-label="Search hymns" /><span>{filtered.length.toString().padStart(2, '0')}</span></div>
      <div className="sample-note"><span>SAMPLE LIBRARY</span> These public-domain hymns are placeholders; the retreat songbook has not been provided.</div>
      <div className="song-list">
        {filtered.map((song, index) => {
          const isOpen = expanded === song.title;
          return <article className={`song-card${isOpen ? ' expanded' : ''}`} key={song.title}>
            <button className="song-row" type="button" onClick={() => setExpanded(isOpen ? null : song.title)} aria-expanded={isOpen}>
              <span className="song-index">{String(index + 1).padStart(2, '0')}</span><span className="song-letter">{song.key}</span><span className="song-title-wrap"><b>{song.title}</b><small>{song.subtitle}</small></span><span className={`song-toggle${isOpen ? ' open' : ''}`}><Icon name="chevron" size={16} /></span>
            </button>
            {isOpen && <div className="lyrics-copy">{song.lyrics.map((verse, verseIndex) => <p key={verseIndex}>{verse}</p>)}</div>}
          </article>;
        })}
        {!filtered.length && <div className="empty-state"><Icon name="music" size={22} /><b>No hymns found</b><span>Try another title.</span></div>}
      </div>
    </section>
  );
}
