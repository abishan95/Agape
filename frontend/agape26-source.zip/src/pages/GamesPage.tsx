import { Attendee } from '../data/mockStore';
import { Icon } from '../components/Icons';

const leaderboard = [
  { team: 'Cedar', points: 420, mark: 'C', color: 'cedar' },
  { team: 'Ember', points: 380, mark: 'E', color: 'ember' },
  { team: 'Flint', points: 340, mark: 'F', color: 'flint' },
  { team: 'Grove', points: 295, mark: 'G', color: 'grove' },
];

const challenges = [
  { number: '01', title: 'Find your rhythm', subtitle: 'A team warm-up', tag: 'SAMPLE CHALLENGE' },
  { number: '02', title: 'The together test', subtitle: 'Build it as one', tag: 'SAMPLE CHALLENGE' },
];

export function GamesPage({ attendee }: { attendee: Attendee }) {
  const teamRank = leaderboard.findIndex((team) => team.team === attendee.Team) + 1;
  return (
    <section className="content-page games-page">
      <div className="page-heading"><p className="eyebrow">PLAY · LAUGH · LIFT EACH OTHER</p><h1>Good things<br /><em>take a team.</em></h1><p className="page-lede">Small challenges, big together energy.</p></div>
      <div className="team-banner"><div className={`team-crest team-${attendee.Team.toLowerCase()}`}>{attendee.Team.slice(0, 1)}</div><div><small>YOUR CREW</small><b>{attendee.Team}</b></div><span className="team-banner-note">{teamRank ? `RANK ${String(teamRank).padStart(2, '0')}` : 'READY TO PLAY'}</span></div>
      <div className="section-heading compact"><div><p className="eyebrow">THE FRIENDLY SHOWDOWN</p><h2>Points table</h2></div><span className="section-index">SAMPLE</span></div>
      <div className="leaderboard-card">
        <div className="leaderboard-head"><span>TEAM</span><span>POINTS</span></div>
        {leaderboard.map((team, index) => (
          <div className={`leaderboard-row${attendee.Team === team.team ? ' own-team' : ''}`} key={team.team}>
            <span className="rank-number">{String(index + 1).padStart(2, '0')}</span><span className={`team-crest mini team-${team.color}`}>{team.mark}</span><b>{team.team}{attendee.Team === team.team && <small> · YOU</small>}</b><span className="points-value">{team.points}<small> pts</small></span>
          </div>
        ))}
        <div className="leaderboard-footer"><span className="status-led" /> Preview scores · not official standings</div>
      </div>
      <div className="section-heading compact challenge-heading"><div><p className="eyebrow">YOUR NEXT MOVE</p><h2>Team challenges</h2></div><span className="challenge-count">02</span></div>
      <div className="challenge-list">
        {challenges.map((challenge) => <article className="challenge-card" key={challenge.number}><span className="challenge-no">{challenge.number}</span><div><small>{challenge.tag}</small><h3>{challenge.title}</h3><p>{challenge.subtitle}</p></div><span className="challenge-arrow"><Icon name="arrow" size={16} /></span></article>)}
      </div>
      <p className="content-footnote">This sample board is a layout preview; official teams, challenges and scores are not connected.</p>
    </section>
  );
}
