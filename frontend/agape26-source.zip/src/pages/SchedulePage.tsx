import { Icon } from '../components/Icons';

const days = [
  { number: '01', date: '27', month: 'DEC', weekday: 'DAY ONE', tone: 'sage' },
  { number: '02', date: '28', month: 'DEC', weekday: 'DAY TWO', tone: 'copper' },
  { number: '03', date: '29', month: 'DEC', weekday: 'DAY THREE', tone: 'violet' },
  { number: '04', date: '30', month: 'DEC', weekday: 'DAY FOUR', tone: 'sage' },
];

export function SchedulePage() {
  return (
    <section className="content-page schedule-page">
      <div className="page-heading"><p className="eyebrow">DECEMBER 2026 · YELAGIRI</p><h1>Four days.<br /><em>One shared story.</em></h1><p className="page-lede">Your retreat itinerary, gathered in one place.</p></div>
      <div className="schedule-overview"><span className="schedule-overview-icon"><Icon name="calendar" size={20} /></span><span><b>27—30 December 2026</b><small>Official programme details to come</small></span><span className="overview-dots">···</span></div>
      <div className="schedule-list">
        {days.map((day) => (
          <article className={`day-card tone-${day.tone}`} key={day.number}>
            <div className="day-date"><span>{day.weekday}</span><b>{day.date}</b><small>{day.month}</small></div>
            <div className="day-details"><span className="day-label">AGAPE · {day.number}</span><h2>{day.weekday[0] + day.weekday.slice(1).toLowerCase()}</h2><p>Programme details will be shared by the retreat team.</p><div className="day-tba"><span className="status-led" /> SCHEDULE TO BE ANNOUNCED</div></div>
            <span className="day-corner" aria-hidden="true">✳</span>
          </article>
        ))}
      </div>
      <aside className="info-note"><Icon name="bell" size={16} /><span>Keep an eye on the broadcast banner for official schedule updates.</span></aside>
    </section>
  );
}
