import { FormEvent, useState } from 'react';
import { Icon } from '../components/Icons';
import { Attendee } from '../data/mockStore';

interface LoginPageProps {
  error: string;
  onLogin: (phone: string) => void;
  onUseDemo: (attendee: Attendee) => void;
  attendees: Attendee[];
}

export function LoginPage({ error, onLogin, onUseDemo, attendees }: LoginPageProps) {
  const [phone, setPhone] = useState('');
  const [localError, setLocalError] = useState('');
  const previewEntries = attendees.filter((attendee) => !attendee.IsSuperuser).slice(0, 2);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLocalError('');
    onLogin(phone);
  }

  return (
    <main className="entry-page login-page">
      <div className="entry-noise" aria-hidden="true" />
      <div className="entry-brand">
        <img className="entry-logo" src="./agape-logo.png" alt="" />
        <div className="brand-label">AGAPE <span>RETREAT 2026</span></div>
      </div>
      <div className="login-orb" aria-hidden="true"><div className="orb-core">A</div><span>27—30<br />DEC</span></div>
      <p className="eyebrow">YOUR PLACE IS WAITING</p>
      <h1 className="entry-title">Find your<br /><em>place here.</em></h1>
      <p className="entry-copy">Sign in with the phone number linked to your retreat registration.</p>
      <form className="login-form" onSubmit={submit}>
        <label htmlFor="phone">PHONE NUMBER</label>
        <div className="phone-field"><span className="country-code">+91</span><input id="phone" inputMode="tel" autoComplete="tel" placeholder="0000000001" value={phone} onChange={(event) => setPhone(event.target.value)} aria-describedby="phone-help login-error" /></div>
        <p className="field-hint" id="phone-help">Preview only · use one of the sample accounts below</p>
        {(error || localError) && <p className="form-error" id="login-error" role="alert">{localError || error}</p>}
        <button className="button button-primary button-wide" type="submit">Continue <Icon name="arrow" size={17} /></button>
      </form>
      <div className="demo-divider"><span /> <small>SAMPLE ACCOUNTS</small> <span /></div>
      <div className="demo-account-list">
        {previewEntries.map((attendee) => (
          <button className="demo-account" type="button" key={attendee.Phone} onClick={() => onUseDemo(attendee)}>
            <span className="demo-avatar">A</span>
            <span><b>{attendee.Name}</b><small>Preview attendee · {attendee.Phone}</small></span>
            <Icon name="chevron" size={16} />
          </button>
        ))}
      </div>
      <p className="demo-warning"><Icon name="shield" size={14} /> Sample data only. The retreat roster is not connected.</p>
    </main>
  );
}
