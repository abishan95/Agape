import { FormEvent, useMemo, useState } from 'react';
import { Icon } from '../components/Icons';
import { Attendee } from '../data/mockStore';

interface AdminPageProps {
  attendees: Attendee[];
  announcement: string;
  onAnnouncementChange: (value: string) => void;
  onBack: () => void;
}

export function AdminPage({ attendees, announcement, onAnnouncementChange, onBack }: AdminPageProps) {
  const [draft, setDraft] = useState(announcement);
  const [query, setQuery] = useState('');
  const [saved, setSaved] = useState(false);
  const filteredAttendees = useMemo(() => attendees.filter((person) => `${person.Name} ${person.Phone} ${person.Team} ${person.Bus}`.toLowerCase().includes(query.toLowerCase())), [attendees, query]);

  function publish(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    onAnnouncementChange(draft.trim());
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2200);
  }

  return (
    <section className="content-page admin-page">
      <button className="back-link" type="button" onClick={onBack}><Icon name="chevron" size={15} /> My Stay</button>
      <div className="page-heading"><p className="eyebrow">SUPERUSER · LOCAL PREVIEW</p><h1>Care for<br /><em>the details.</em></h1><p className="page-lede">A small control room for the retreat team.</p></div>
      <div className="admin-warning"><Icon name="shield" size={17} /><div><b>Preview-only admin</b><p>These changes live only in this browser. This is not a secure, shared admin system.</p></div></div>
      <form className="admin-panel" onSubmit={publish}>
        <div className="admin-panel-heading"><span className="admin-panel-icon"><Icon name="bell" size={18} /></span><div><small>ANNOUNCEMENTS</small><b>Broadcast a note</b></div><span className="local-tag">LOCAL</span></div>
        <label htmlFor="announcement">MESSAGE FOR THE HOME BANNER</label>
        <textarea id="announcement" maxLength={150} value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Share a short retreat update…" />
        <div className="textarea-meta"><span>Preview text · {draft.length}/150</span><button className="button button-primary button-small" type="submit">{saved ? <><Icon name="check" size={15} /> Saved</> : 'Save banner'}</button></div>
      </form>
      <div className="section-heading compact admin-roster-heading"><div><p className="eyebrow">SAMPLE DATA ONLY</p><h2>Roster lookup</h2></div><span className="roster-count">{filteredAttendees.length.toString().padStart(2, '0')}</span></div>
      <div className="song-search roster-search"><Icon name="search" size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search name, phone or team" aria-label="Search attendee roster" /></div>
      <div className="roster-list">{filteredAttendees.map((person) => <article className="roster-entry" key={person.Phone}><span className={`roster-avatar${person.IsSuperuser ? ' is-admin' : ''}`}>{person.Name.slice(0, 1)}</span><div><b>{person.Name}{person.IsSuperuser && <span className="superuser-pill">SUPERUSER</span>}</b><small>{person.Phone} · {person.Team}</small><span className="roster-meta">{person.Bus} · {person.Room}</span></div></article>)}{!filteredAttendees.length && <div className="empty-state"><Icon name="search" size={22} /><b>No matches</b><span>Try a different name or team.</span></div>}</div>
      <p className="content-footnote">The Master Google Spreadsheet and live attendee data are not connected to this preview.</p>
    </section>
  );
}
