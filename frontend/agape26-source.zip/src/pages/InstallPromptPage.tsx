import { useState } from 'react';
import { Icon } from '../components/Icons';

export interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

interface InstallPromptPageProps {
  installPrompt: InstallPromptEvent | null;
  onInstallPromptUsed: () => void;
  onContinue: () => void;
}

export function InstallPromptPage({ installPrompt, onInstallPromptUsed, onContinue }: InstallPromptPageProps) {
  const [showSteps, setShowSteps] = useState(false);

  async function install() {
    if (!installPrompt) {
      setShowSteps(true);
      return;
    }
    try {
      await installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        onInstallPromptUsed();
        return;
      }
    } catch {
      // Fall back to platform instructions if the native prompt is unavailable.
    }
    setShowSteps(true);
  }

  return (
    <main className="entry-page install-page">
      <div className="entry-noise" aria-hidden="true" />
      <div className="entry-brand">
        <img className="entry-logo" src="./agape-logo.png" alt="" />
        <div className="brand-label">CICC RETREAT <span>2026</span></div>
      </div>
      <div className="install-art" aria-hidden="true">
        <div className="orbit orbit-one" /><div className="orbit orbit-two" />
        <img className="install-logo" src="./agape-logo.png" alt="" />
        <span className="art-dot dot-a" /><span className="art-dot dot-b" /><span className="art-dot dot-c" />
      </div>
      <p className="eyebrow">DEC 27 — 30 · YELAGIRI</p>
      <h1 className="entry-title">A place to belong.<br /><em>A moment to grow.</em></h1>
      <p className="entry-copy">Your retreat pass, programme, songs and team — together, wherever you are.</p>
      <div className="install-actions">
        <button className="button button-primary button-wide" type="button" onClick={install}>
          <Icon name="install" size={18} /> {installPrompt ? 'Add AGAPE to your home screen' : 'Install or learn how'}
        </button>
        {showSteps && (
          <div className="instruction-card" role="status">
            <strong>On iPhone or iPad</strong>
            <p>Open this page in Safari, tap <b>Share</b>, then choose <b>Add to Home Screen</b>.</p>
            <strong>On Android</strong>
            <p>Open the browser menu and choose <b>Install app</b> or <b>Add to Home screen</b>.</p>
          </div>
        )}
        <button className="text-button" type="button" onClick={onContinue}>Continue in browser <Icon name="arrow" size={16} /></button>
      </div>
      <div className="entry-footnote"><span className="status-led" /> A small space for the whole retreat</div>
    </main>
  );
}
